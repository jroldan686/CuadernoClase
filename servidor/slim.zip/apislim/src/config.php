<?php 
define('TABLA_ALUMNO', "alumno");
define('TABLA_FALTA', "falta");
define('OK', 200);
define('NOT_COMPLETED', 202);
define('CONFLICT', 409);
class Result {
    var $code;
    var $status;
    var $message;
    var $alumnos;
    var $faltas;
    var $last;
    function setCode($c) {$this->code = $c;}
    function getCode() {return $this->code;}
    function setStatus($s) {$this->status = $s;}
    function getStatus() {return $this->status;}
    function setMessage($m) {$this->message = $m;}
    function getMessage() {return $this->message;}
    function setAlumnos($a) {$this->alumnos = $a;}
    function getAlumnos() {return $this->alumnos;}
    function setFaltas($f) {$this->faltas = $f;}
    function getFaltas() {return $this->faltas;}
    function setLast($l) {$this->last = $l;}
    function getLast() {return $this->last;}
}
class Alumno {
    var $id;
    var $nombre;
    var $direccion;
    var $ciudad;
    var $codpostal;
    var $telefono;
    var $email;
}
class Falta {
    var $id;
    var $fecha;
    var $alumno;
    var $tipo;
    var $trabajo;
    var $actitud;
    var $observaciones;
}
class Email {
    var $from;
    var $password;
    var $to;
    var $subject;
    var $message;
}
?>
