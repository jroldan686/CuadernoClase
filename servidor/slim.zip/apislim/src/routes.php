<?php

// Routes

/*
$app->get('/[{name}]', function ($request, $response, $args) {
    // Sample log message
    $this->logger->info("Slim-Skeleton '/' route");

    // Render index view
    return $this->renderer->render($response, 'index.phtml', $args);
});
*/

$app->get("/", function ($request, $response) {

	$this->response->withHeader('Content-type', 'text/html; charset=UTF-8');
	return $this->response->write(
		"<h1>RESTful API Slim</h1>
		<a href ='doc/index.html'>API Documentation</a>");
});

// get all alumns
$app->get('/alumnos', function ($request, $response) {
	$result = new Result();

	$key = $request->getHeader('apikey');

	if($key[0] != "miclaveenclaro") {
		$result->setCode(FALSE);
		$result->setStatus(403);
		$result->setMessage("forbidden");
	} else {
	try {
		$dbquery =  $this->db->prepare("SELECT * FROM " . TABLA_ALUMNO);
		$dbquery->execute();
		$alumnos = $dbquery->fetchAll();

		$result->setCode(TRUE);
		$result->setStatus(OK);
		$result->setAlumnos($alumnos);
	} catch (PDOException $e) {
		$result->setCode(FALSE);
		$result->setStatus(CONFLICT);
		$result->setMessage("Error: " . $e->getMessage());
	}
}
	return $this->response->withJson($result);
});

$app->get('/faltas', function ($request, $response) {
        $result = new Result();

        $key = $request->getHeader('apikey');

        if($key[0] != "miclaveenclaro") {
                $result->setCode(FALSE);
                $result->setStatus(403);
                $result->setMessage("forbidden");
        } else {
        try {
                //$dbquery =  $this->db->prepare("SELECT alumno, tipo, trabajo, actitud, observaciones FROM ".TABLA_FALTA." WHERE fecha = CURDATE()");
                $dbquery =  $this->db->prepare("SELECT * FROM ".TABLA_FALTA);
                $dbquery->execute();
                $faltas = $dbquery->fetchAll();


                $result->setCode(TRUE);
		$result->setStatus(OK);
                $result->setFaltas($faltas);
        } catch (PDOException $e) {
                $result->setCode(FALSE);
                $result->setStatus(CONFLICT);
                $result->setMessage("Error: " . $e->getMessage());
        }
}
        return $this->response->withJson($result);
});


$app->get('/alumno/[{id}]', function ($request, $response, $args) {
	$result = new Result();

	$key = $request->getHeader('apikey');

        if($key[0] != "miclaveenclaro") {
                $result->setCode(FALSE);
                $result->setStatus(403);
                $result->setMessage("forbidden");
        } else {
	try {
		$dbquery = $this->db->prepare("SELECT * FROM " . TABLA_ALUMNO . " WHERE id = ?");
		$dbquery->bindParam(1,  $args['id']);
		$dbquery->execute();
		$alumnos = $dbquery->fetchObject();

		if ($alumnos != null) {
			$result->setCode(TRUE);
			$result->setStatus(OK);
			$result->setAlumnos($alumnos);
		}
		else {
			$result->setCode(FALSE);
			$result->setStatus(NOT_COMPLETED);
			$result->setMessage("Does the alumn exist?");
		}
	} catch (PDOException $e) {
		$result->setCode(FALSE);
		$result->setStatus(CONFLICT);
		$result->setMessage("Error: " . $e->getMessage());
	}
}
	return $this->response->withJson($result);
});

$app->post('/alumno', function ($request, $response) {

	$result = new Result();

	$key = $request->getHeader('apikey');

        if($key[0] != "miclaveenclaro") {
                $result->setCode(FALSE);
                $result->setStatus(403);
                $result->setMessage("forbidden");
        } else {
	//lock the table
	try {
		$input = $request->getParsedBody();
		$dbquery =  $this->db->prepare("INSERT INTO " . TABLA_ALUMNO . " (nombre, direccion, ciudad, codpostal, telefono, email) VALUES (?, ?, ?, ?, ?, ?)");
		$dbquery->bindParam(1, $input['nombre']);
                $dbquery->bindParam(2, $input['direccion']);
                $dbquery->bindParam(3, $input['ciudad']);
		$dbquery->bindParam(4, $input['codpostal']);
                $dbquery->bindParam(5, $input['telefono']);
                $dbquery->bindParam(6, $input['email']);

		$dbquery->execute();
		$number = $dbquery->rowCount();
		$lastId = $this->db->lastInsertId();
		if ($number > 0) {
			$result->setCode(TRUE);
			$result->setStatus(OK);
			$result->setLast($lastId);
		}
		else {
			$result->setCode(FALSE);
			$result->setStatus(NOT_COMPLETED);
			$result->setMessage("NOT INSERTED");
		}
	} catch (PDOException $e) {
		$result->setCode(FALSE);
		$result->setStatus(CONFLICT);
		$result->setMessage("Error: " . $e->getMessage());
	}
}
	return $this->response->withJson($result);
});
$app->post('/falta', function ($request, $response) {

	$result = new Result();

	$key = $request->getHeader('apikey');

        if($key[0] != "miclaveenclaro") {
                $result->setCode(FALSE);
                $result->setStatus(403);
                $result->setMessage("forbidden");
        } else {
	//lock the table
	try {
		$input = $request->getParsedBody();
		$dbquery =  $this->db->prepare("INSERT INTO " . TABLA_FALTA . " (fecha, alumno, tipo, trabajo, actitud, observaciones) VALUES (CURDATE(), ?, ?, ?, ?, ?)");
		$dbquery->bindParam(1, $input['alumno']);
		$dbquery->bindParam(2, $input['tipo']);
                $dbquery->bindParam(3, $input['trabajo']);
                $dbquery->bindParam(4, $input['actitud']);
		$dbquery->bindParam(5, $input['observaciones']);

		$dbquery->execute();
		$number = $dbquery->rowCount();
		$lastId = $this->db->lastInsertId();
		if ($number > 0) {
			$result->setCode(TRUE);
			$result->setStatus(OK);
			$result->setLast($lastId);
		}
		else {
			$result->setCode(FALSE);
			$result->setStatus(NOT_COMPLETED);
			$result->setMessage("NOT INSERTED");
		}
	} catch (PDOException $e) {
		$result->setCode(FALSE);
		$result->setStatus(CONFLICT);
		$result->setMessage("Error: " . $e->getMessage());
	}
}
	return $this->response->withJson($result);
});
$app->put('/alumno/[{id}]', function ($request, $response, $args) {

        $result = new Result();

        $key = $request->getHeader('apikey');

        if($key[0] != "miclaveenclaro") {
                $result->setCode(FALSE);
                $result->setStatus(403);
                $result->setMessage("forbidden");
        } else {
	 try {
                $input = $request->getParsedBody();
                $dbquery = $this->db->prepare("UPDATE " . TABLA_ALUMNO . " SET nombre = ?, direccion = ?, ciudad  = ?, codpostal = ?, telefono = ?, email = ? WHERE id = ?");
                $dbquery->bindParam(1, $input['nombre']);
                $dbquery->bindParam(2, $input['direccion']);
                $dbquery->bindParam(3, $input['ciudad']);
                $dbquery->bindParam(4, $input['codpostal']);
                $dbquery->bindParam(5, $input['telefono']);
                $dbquery->bindParam(6, $input['email']);
                $dbquery->bindParam(7, $args['id']);

                $dbquery->execute();
                $number = $dbquery->rowCount();
                //$dbquery =  $this->db->prepare("SELECT * FROM " . TABLE);
                //$dbquery->execute();
                //$sites = $dbquery->fetchAll();
                if ($number > 0) {
                        $result->setCode(TRUE);
                        $result->setStatus(OK);
                        //$result->setSites($sites);
		 }
                else {
                        $result->setCode(FALSE);
                        $result->setStatus(NOT_COMPLETED);
                        $result->setMessage("NOT UPDATED");
                }
	} catch (PDOException $e) {
                $result->setCode(FALSE);
                $result->setStatus(CONFLICT);
                $result->setMessage("Error: " . $e->getMessage());
        }
}
        return $this->response->withJson($result);
});

$app->put('/falta/[{id}]', function ($request, $response, $args) {
	$result = new Result();
	$key=$request->getHeader('apikey');
	if($key[0]!="miclaveenclaro"){
  		$result->setCode(FALSE);
  		$result->setStatus(403);
  		$result->setMessage("forbidden");
	}
	else{
    	try {
        	$input = $request->getParsedBody();
        	$dbquery = $this->db->prepare("UPDATE ". TABLA_FALTA ." SET alumno = ?, tipo = ?, trabajo=?, actitud=?, observaciones=? WHERE id = ?");
        	$dbquery->bindParam(1, $input['alumno']);
        	$dbquery->bindParam(2, $input['tipo']);
        	$dbquery->bindParam(3, $input['trabajo']);
        	$dbquery->bindParam(4, $input['actitud']);
        	$dbquery->bindParam(5, $input['observaciones']);
        	$dbquery->bindParam(6, $input['id']);
        	$dbquery->execute();
        	$number = $dbquery->rowCount();
        	if ($number > 0) {
            		$dbquery = $this->db->prepare("SELECT * FROM ". TABLA_FALTA ." WHERE fecha = CURDATE()");
            		$dbquery->execute();
            		$abst = $dbquery->fetchAll();
            		$result->setCode(TRUE);
            		$result->setStatus(OK);
            		$result->setFaltas($abst);
        	}
        	else {
            		$result->setCode(FALSE);
            		$result->setStatus(NOT_COMPLETED);
            		$result->setMessage("NOT UPDATED");
        	}
    	} catch (PDOException $e) {
        	$result->setCode(FALSE);
        	$result->setStatus(CONFLICT);
        	$result->setMessage("Error: " . $e->getMessage());
    	}
}
	return 	$this->response->withJson($result);
});

$app->delete('/alumno/[{id}]', function ($request, $response, $args) {

	$result = new Result();
	$key = $request->getHeader('apikey');

        if($key[0] != "miclaveenclaro") {
                $result->setCode(FALSE);
                $result->setStatus(403);
                $result->setMessage("forbidden");
        } else {
	try {
		$dbquery = $this->db->prepare("DELETE FROM " . TABLA_ALUMNO . " WHERE id = ?");
		$dbquery->bindParam(1, $args['id']);
		$dbquery->execute();
		$number = $dbquery->rowCount();
		//$dbquery =  $this->db->prepare("SELECT * FROM " . TABLE);
		//$dbquery->execute();
		//$sites = $dbquery->fetchAll();
		if ($number > 0) {
			$result->setCode(TRUE);
			$result->setStatus(OK);
			//$result->setSites($sites);
		}
		else {
			$result->setCode(FALSE);
			$result->setStatus(NOT_COMPLETED);
			$result->setMessage("NOT DELETED");
		}
	} catch (PDOException $e) {
		$result->setCode(FALSE);
		$result->setStatus(CONFLICT);
		$result->setMessage("Error: " . $e->getMessage());
	}
}
	return $this->response->withJson($result);
});

//incluye envío de emails usando alumno@portadaalta.info
$app->post("/email", function ($request, $response) {
	$key = $request->getHeader('apikey');

        if($key[0] != "miclaveenclaro") {
                $result->setCode(FALSE);
                $result->setStatus(403);
                $result->setMessage("forbidden");
        } else {
	$input = $request->getParsedBody();
	$result = sendEmail($input['from'], $input['password'], $input['to'], $input['subject'], $input['message']);
	}
	return $this->response->withJson($result);
});

function sendEmail($from, $password, $to, $subject, $message) {

	$result = new Result();
	$mail = new PHPMailer(true); 	// the true param means it will throw exceptions on errors, which we need to catch
	$mail->IsSMTP(); 		// telling the class to use SMTP

	try {
	    $mail->SMTPDebug  = 2;			// enables SMTP debug information (for testing)
	    //$mail->SMTPDebug  = 0;
	    $mail->SMTPAuth   = true;			// enable SMTP authentication
	    $mail->SMTPSecure = "None";                 	// sets the prefix to the server
	    $mail->Host       ="mail.portadaalta.info";
	    //$mail->Host       = "smtp.gmail.com";      	// sets GMAIL as the SMTP server
	    //$mail->Host       = "smtp.openmailbox.org";
	    $mail->Port       = 25;                   	// set the SMTP port for the GMAIL server
	    $mail->Username   = $from;			// GMAIL username
	    $mail->Password   = $password;		// GMAIL password
	    $mail->AddAddress($to);			// Receiver email
	    $mail->SetFrom($from, 'Profesor');		// email sender
	    $mail->AddReplyTo($from, 'Profesor');	// email to reply
	    $mail->Subject = $subject;			// subject of the message
	    $mail->AltBody = 'Message in plain text';	// optional - MsgHTML will create an alternate automatically
	    $mail->MsgHTML($message);			// message in the email
	    //$mail->AddAttachment('images/phpmailer.gif');      // attachment
	    $mail->Send();
	    $result->setCode(TRUE);
	    $result->setMessage("Message Sent OK to " . $to);
	} catch (phpmailerException $e) {
	    //echo $e->errorMessage(); 			//Pretty error messages from PHPMailer
	    $result->setCode(FALSE);
    	$result->setMessage("Error: " . $e->errorMessage());
	} catch (Exception $e) {
	    //echo $e->getMessage(); 			//Boring error messages from anything else!
	    $result->setCode(FALSE);
    	$result->setMessage("Error: " . $e->getMessage());
	}
	return $result;
}
